
typedef struct Dwarf_Type_Context_s *Dwarf_Type_Context;

/* type never completed  see dwarf_global.h */
