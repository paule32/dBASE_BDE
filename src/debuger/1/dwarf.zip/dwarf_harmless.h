void _dwarf_harmless_init(struct Dwarf_Harmless_s *dhp,unsigned size);
void _dwarf_harmless_cleanout(struct Dwarf_Harmless_s *dhp);
