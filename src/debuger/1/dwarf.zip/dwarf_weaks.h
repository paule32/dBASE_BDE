
typedef struct Dwarf_Weak_Context_s *Dwarf_Weak_Context;

/* struct  never completed: see dwarf_global.h */
