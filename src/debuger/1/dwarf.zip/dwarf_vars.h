typedef struct Dwarf_Var_Context_s *Dwarf_Var_Context;

/* struct  never completed: see dwarf_global.h */
